//
//  ViewController.swift
//  Mudhagoni_FormatName
//
//  Created by Ajaykumar on 01/02/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var firstNameTextField: UITextField!
    
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickOfSubmit(_ sender: Any) {
        
        var fname = firstNameTextField.text!
        var lname = lastNameTextField.text!
        fullNameLabel.text = "\(fname),\(lname)"
        var fi = fname.prefix(1)
        var li = lname.prefix(1)
        var ini = fi + li
        initialsLabel.text = "\(ini)"
        
    }
    
    @IBAction func onClickOfReset(_ sender: Any) {
        
        self.firstNameTextField.text = nil
        self.lastNameTextField.text = nil
        self.fullNameLabel.text = nil
        self.initialsLabel.text = nil
        firstNameTextField.becomeFirstResponder()
        
    }
    

}

