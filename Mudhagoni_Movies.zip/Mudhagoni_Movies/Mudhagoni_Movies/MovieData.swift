//
//  MovieData.swift
//  Mudhagoni_Movies
//
//  Created by Mudhagoni,Sai Kumar on 4/27/22.
//

import Foundation
import UIKit

struct Movie {
    var title:String
    var image:UIImage
    var releasedYear:String
    var movieRating:String
    var boxOffice:String
    var moviePlot:String
    var cast:[String] = []
}

struct Genre {
    var category:String = ""
    var movies:[Movie] = []
}

let category1: Genre = Genre(category: "Documentry", movies: [Movie(title: "I Am Heath Ledger", image: UIImage(named: "dc1")!, releasedYear: "2020", movieRating: "4.9", boxOffice: "456M", moviePlot: "Three people pay respects to Heath Ledger.", cast: ["Naomi Watts", "Matt Amato"]), Movie(title: "Writing With Fire", image: UIImage(named: "dc2")!, releasedYear: "2020", movieRating: "4.8", boxOffice: "539 million", moviePlot: "Moral of Justice", cast: ["Nathan", "Himaja"]), Movie(title: "For the Love Of Spock", image: UIImage(named: "dc3")!, releasedYear: "2020", movieRating: "4.6", boxOffice: "968.1M", moviePlot: "Spock had a troubled childhood due to his mixed heritage.", cast: ["Micheal", "Ulhura"]), Movie(title: "Meru", image: UIImage(named: "dc4")!, releasedYear: "2021", movieRating: "4.1", boxOffice: "345M", moviePlot: "The winner of the life", cast: ["Kyra", "Mathew"]), Movie(title: "Belle", image: UIImage(named: "dc5")!, releasedYear: "2019", movieRating: "4.2", boxOffice: "157.8 million", moviePlot: "The air fighters", cast: ["John Andrew", "John Andrew"])])

let category2: Genre = Genre(category: "Horror", movies: [Movie(title: "The Curse of La Llorona", image: UIImage(named: "h1")!, releasedYear: "2019", movieRating: "4.9", boxOffice: "770 Million", moviePlot: "Surviving La Llorona's deadly wrath.", cast: ["Joseph", "Micheal"]), Movie(title: "Things Heard & Seen", image: UIImage(named: "h2")!, releasedYear: "2019", movieRating: "4.9", boxOffice: "543M", moviePlot: "A young artist begins to suspect that their home harbours some dark secrets.", cast: ["Shari", "Robert"]), Movie(title: "The Rental", image: UIImage(named: "h3")!, releasedYear: "2019", movieRating: "4.6", boxOffice: "318M", moviePlot: "TTwo couples on an oceanside getaway grow suspicious.", cast: ["Dave", "Franco"]), Movie(title: "The Hole in the Ground", image: UIImage(named: "h4")!, releasedYear: "2022", movieRating: "4.5", boxOffice: "554M", moviePlot: "Sarah's young son disappears into the woods behind their rural home.", cast: ["Stephen McKen", "Lee Corin"]), Movie(title: "A Cure for Wellness", image: UIImage(named: "h5")!, releasedYear: "2017", movieRating: "4.8", boxOffice: "423M", moviePlot: "A psychological thriller.", cast: ["Dane DeHaan", "Jason Isaacs"])])

let category3: Genre = Genre(category: "Drama", movies: [Movie(title: "Rangasthalam", image: UIImage(named: "d1")!, releasedYear: "2017", movieRating: "4.6", boxOffice: "423M", moviePlot: "Chitti Babuis is a happy-go-lucky man.", cast: ["Ram Charan", "Samantha"]), Movie(title: "Hello Guru Premokosame", image: UIImage(named: "d2")!, releasedYear: "2016", movieRating: "4.7", boxOffice: "105M", moviePlot: "Love story between two people.", cast: ["Ram", "Anupamma"]), Movie(title: "Arjun Reddy", image: UIImage(named: "d3")!, releasedYear: "2014", movieRating: "4.7", boxOffice: "322M", moviePlot: "A sad love story", cast: ["Vijay", "Shalini"]), Movie(title: "Venky Mama", image: UIImage(named: "d4")!, releasedYear: "2015", movieRating: "4.9", boxOffice: "240M", moviePlot: "A family story.", cast: ["Venkatesh", "Hansika"]), Movie(title: "Vakeel Saab", image: UIImage(named: "d5")!, releasedYear: "2021", movieRating: "4.9", boxOffice: "110M", moviePlot: "Fighting for the justice.", cast: ["Pawan Kalyan","Samantha"])])


let categoryArray = [category1, category2, category3]
