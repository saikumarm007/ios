//
//  ViewController.swift
//  Mudhagoni_GroceryApp
//
//  Created by Mudhagoni,Sai Kumar on 4/5/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

