//
//  ViewController.swift
//  Mudhagoni_SearchApp
//
//  Created by Student on 2/27/22.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
//    @IBOutlet weak var imageName: UILabel!
    
    @IBOutlet weak var searchButtonAction: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    @IBOutlet weak var showPrevImagesBtn: UIButton!
    
    @IBOutlet weak var showNextImagesBtn: UIButton!
    
    var arr = [["actor1","actor2","actor3","actor4","actor5"],["flower1","flower2","flower3","flower4","flower5"],["animal1","animal2","animal3","animal4","animal5",],["bg","404"]]
    
    var actors = ["actor","actors","hero","hollywood","celebrity"]
    
    var books = ["flowers","flower","rose","roses"]
    
    var animals = ["animals","animal", "lion","elephant","rhino","buffalo","leopard"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        searchButtonAction.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
//        imageName.text = nil
    }
    
    
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButtonAction.isEnabled = true
        if(sender.text == ""){
            searchButtonAction.isEnabled = false
            
        }
        else{
//            showPrevImagesBtn.isHidden = false
//            showNextImagesBtn.isHidden = false
            showPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            searchButtonAction.isEnabled = true
            resetButton.isHidden = false
        }
    }
    
    
    
    var actor = [["Scarlett Johansson","Natalie Portman","Jennifer Lawrence","Mila Kunis","Jennifer Aniston"],["An actrees is a person who acts, or has a role (a part) in a movie, television show, play, or radio show. Actrees may be professional or not. Sometimes Actrees only sing or dance, or sometimes they only work on radio."]]
    
    var flower = [["Roses","Sun Flower","Flower","Red Sun Flower","Blue Roses"],["A flower, also known as a bloom or blossom, is the reproductive structure found in flowering plants. The flower structure contains the plant's reproductive organs, and its function is to produce seeds through reproduction."]]

    var animal = [["Rat","Lion","Humming Bird","Tiger","Cuckoos"],["Animals are multicellular eukaryotes whose cells are bound together by collagen. Animals dominate human conceptions of life on Earth because of their size, diversity, abundance, and mobility. The presence of muscles and mobility is one of the primary characteristics of the animal kingdom."]]
    
    
    
    @IBAction func searchButtonActionAction(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        showPrevImagesBtn.isHidden = false
        showNextImagesBtn.isHidden = false
        showPrevImagesBtn.isEnabled = false
        showNextImagesBtn.isEnabled = false
        resetButton.isEnabled = true
        if(actors.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            showPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[0][imag1])
//            imageName.text = actor[0][name1]
            topic = 1
            topicInfoText.text = actor[1][0]
        }
        else if(books.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            showPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[1][imag2])
//            imageName.text = book[0][name2]
            topic = 2
            topicInfoText.text = flower[1][0]
        }
        else if(animals.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            showPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[2][imag3])
//            imageName.text = book[0][name3]
            topic = 3
            topicInfoText.text = animal[1][0]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])
//            resultImage.image = nil
            topicInfoText.text = nil
            
//            imageName.text = nil
            showPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            resetButton.isEnabled = true
        }
        
        
    }
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
        
    }
    
    @IBAction func showNextImagesBtn(_ sender: Any) {
        if(topic == 1){
            imag1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
        }
    }
    
    
    @IBAction func resetButton(_ sender: Any) {
        showPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
//        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
//        imageName.text = nil
        searchTextField.text = nil
        resetButton.isHidden = true
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        topic = 0
        
        
    }
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == arr[0].count-1 {
                showNextImagesBtn.isEnabled = false
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
//                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][0]
            }
            else if(imag1 == 0){
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
//                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][0]
            }
            else{
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[0][imag1])
//                imageName.text = actor[0][name1]
                topicInfoText.text = actor[1][0]
            }
        }
        if(topic == 2){
            if imag2 == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
//                imageName.text = book[0][name2]
                topicInfoText.text = flower[1][0]
            }
            else if(imag2 == 0){
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
//                imageName.text = book[0][name2]
                topicInfoText.text = flower[1][0]
            }
            else{
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[1][imag2])
//                imageName.text = book[0][name2]
                topicInfoText.text = flower[1][0]
                
            }
        }
        if(topic == 3){
            if imag3 == arr[1].count-1 {
                showNextImagesBtn.isEnabled = false
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
//                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][0]
            }
            else if(imag3 == 0){
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
//                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][0]
            }
            else{
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: arr[2][imag3])
//                imageName.text = animal[0][name3]
                topicInfoText.text = animal[1][0]
                
            }
        }
    }
    

    
    
    
    
    
}
